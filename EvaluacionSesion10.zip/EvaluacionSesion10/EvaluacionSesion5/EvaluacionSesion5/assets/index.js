
$(document).ready(function() {
  $('.ver-mas').click(function(event) {
    event.preventDefault();
    
  
    var destino = $(this).data('info');
    var descripcion = $(this).data('description');
    var imagen = $(this).data('img');
    
   
    $('#info-title').text(destino);
    $('#info-content').text(descripcion);
    $('#info-img').attr('src', imagen);
    
 
    $('#info-popup').fadeIn();
  });

  $('#close-popup').click(function() {
    $('#info-popup').fadeOut();
  });

  $(document).click(function(event) {
    if (!$(event.target).closest('.ver-mas, #info-popup').length) {
      $('#info-popup').fadeOut();
    }
  });
});
